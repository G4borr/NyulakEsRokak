﻿namespace Ciklus_Lib
{
    public class Rabbit
    {
        public int HungerLevel { get; set; } 
        public bool IsAlive { get; set; } 
        public Rabbit()
        {
            HungerLevel = 5; 
            IsAlive = true; 
        }
        public void Eat(Field field)
        {
            
            if (field.GrassState == 1) 
            {
                HungerLevel++; 
                field.GrassState = 0; 
            }
            else if (field.GrassState == 2) 
            {
                HungerLevel += 2; 
                field.GrassState = 1; 
            }
            
            if (HungerLevel > 5)
            {
                HungerLevel = 5; 
            }
        }
        public void DecreaseHunger()
        {
            HungerLevel--; 
            if (HungerLevel <= 0)
            {
                IsAlive = false; 
            }
        }
    }
}
