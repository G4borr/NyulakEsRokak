﻿namespace Ciklus_Lib
{
    public class Field
    {
        public int GrassState { get; set; } 
        public Rabbit? Rabbit { get; set; } 
        public Fox? Fox { get; set; } 

        public Field()
        {
            GrassState = 0;
            Rabbit = null;
            Fox = null;
        }       
        public void GrowGrass()
        {
            if (Rabbit == null)
            {
                if (GrassState < 2)
                    GrassState++;
            }
        }
    }
}
