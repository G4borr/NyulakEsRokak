﻿namespace Ciklus_Lib
{
    public class Rabbit
    {
        public int HungerLevel { get; set; } // Éhség szint
        public bool IsAlive { get; set; } // Életben van-e

        public Rabbit()
        {
            HungerLevel = 5; // Kezdeti éhség szint
            IsAlive = true;  // A nyúl életben van
        }

        // Nyúl eszik a mezőn lévő fűből
        public void Eat(Field field)
        {
            if (field.GrassState > 0) // Ha van fű (GrassState > 0)
            {
                HungerLevel = Math.Min(HungerLevel + 1, 5); // Növeljük az éhség szintet, de max. 5 lehet
                field.GrassState--; // Csökkentjük a fű szintjét
            }
        }

        // Nyúl mozog egyszerűen egy szomszédos üres mezőre
        public void Move(Field[,] grid, int x, int y)
        {
            // Próbál mozogni jobbra, balra, fel vagy le, ha van üres mező
            if (x > 0 && grid[x - 1, y].Rabbit == null && grid[x - 1, y].Fox == null)
            {
                grid[x - 1, y].Rabbit = this;
                grid[x, y].Rabbit = null;
            }
            else if (x < grid.GetLength(0) - 1 && grid[x + 1, y].Rabbit == null && grid[x + 1, y].Fox == null)
            {
                grid[x + 1, y].Rabbit = this;
                grid[x, y].Rabbit = null;
            }
            else if (y > 0 && grid[x, y - 1].Rabbit == null && grid[x, y - 1].Fox == null)
            {
                grid[x, y - 1].Rabbit = this;
                grid[x, y].Rabbit = null;
            }
            else if (y < grid.GetLength(1) - 1 && grid[x, y + 1].Rabbit == null && grid[x, y + 1].Fox == null)
            {
                grid[x, y + 1].Rabbit = this;
                grid[x, y].Rabbit = null;
            }
        }

        // Éhség csökkentése és halál ellenőrzése
        public void DecreaseHunger()
        {
            HungerLevel--; // Éhség szint csökken
            if (HungerLevel <= 0)
            {
                IsAlive = false; // A nyúl elpusztul, ha az éhség eléri a nullát
            }
        }
    }
}
