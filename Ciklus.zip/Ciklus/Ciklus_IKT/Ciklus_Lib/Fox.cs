﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ciklus_Lib
{
    public class Fox
    {
        public int HungerLevel { get; set; } 
        public bool IsAlive { get; set; }

        public Fox()
        {
            HungerLevel = 10;
            IsAlive = true;
        }

        public void HuntRabbit(Field field)
        {
            if (field.Rabbit != null)
            {
                field.Rabbit = null; 
                HungerLevel = Math.Min(HungerLevel + 3, 10); 
            }
        }

        public void DecreaseHunger()
        {
            HungerLevel--;
            if (HungerLevel <= 0)
            {
                IsAlive = false;
            }
        }
    }
}
