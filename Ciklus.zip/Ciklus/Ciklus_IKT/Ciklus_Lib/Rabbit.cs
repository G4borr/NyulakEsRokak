﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ciklus_Lib
{
    public class Rabbit
    {
        public int HungerLevel { get; set; } 
        public bool IsAlive { get; set; }

        public Rabbit()
        {
            HungerLevel = 5;
            IsAlive = true;
        }

        public void Eat(Field field)
        {
            if (field.GrassState == 1)
            {
                HungerLevel = Math.Min(HungerLevel + 1, 5); 
                field.GrassState = 0; 
            }
            else if (field.GrassState == 2)
            {
                HungerLevel = Math.Min(HungerLevel + 2, 5); 
                field.GrassState = 1; 
            }
        }

        public void DecreaseHunger()
        {
            HungerLevel--;
            if (HungerLevel <= 0)
            {
                IsAlive = false;
            }
        }
    }
}
