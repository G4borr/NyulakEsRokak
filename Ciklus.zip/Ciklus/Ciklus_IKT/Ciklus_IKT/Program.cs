﻿// IKT projektmunka Farkas Botond, Pongrácz Gábor
using Ciklus_Lib;
    
   
        int width = 10;
        int height = 10;
        Field[,] grid = new Field[width, height];

        for (int i = 0; i < width; i++)
        {
            for (int j = 0; j < height; j++)
            {
                grid[i, j] = new Field();
            }
        }

    
        grid[1, 1].Rabbit = new Rabbit();
        grid[3, 3].Fox = new Fox();

    
        for (int turn = 0; turn < 100; turn++) 
        {
            Console.WriteLine($"Turn {turn + 1}");

        
            for (int i = 0; i < width; i++)
            {
                for (int j = 0; j < height; j++)
                {
                    grid[i, j].GrowGrass();
                }
            }

       
            for (int i = 0; i < width; i++)
            {
                for (int j = 0; j < height; j++)
                {
                    if (grid[i, j].Rabbit != null)
                    {
                        grid[i, j].Rabbit.Eat(grid[i, j]);
                        grid[i, j].Rabbit.DecreaseHunger();
                    }
                }
            }

        
            for (int i = 0; i < width; i++)
            {
                for (int j = 0; j < height; j++)
                {
                    if (grid[i, j].Fox != null)
                    {
                        grid[i, j].Fox.HuntRabbit(grid[i, j]);
                        grid[i, j].Fox.DecreaseHunger();
                    }
                }
            }

        
            PrintGrid(grid);
        }
    

    static void PrintGrid(Field[,] grid)
    {
        for (int i = 0; i < grid.GetLength(0); i++)
        {
            for (int j = 0; j < grid.GetLength(1); j++)
            {
                if (grid[i, j].Rabbit != null)
                {
                    Console.Write("R ");
                }
                else if (grid[i, j].Fox != null)
                {
                    Console.Write("F ");
                }
                else
                {
                    Console.Write(". ");
                }
            }
            Console.WriteLine();
        }
    }

Console.WriteLine("Szimuláció vége");
